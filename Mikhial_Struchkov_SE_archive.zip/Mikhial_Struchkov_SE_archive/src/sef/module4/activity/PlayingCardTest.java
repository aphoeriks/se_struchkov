package sef.module4.activity;

import junit.framework.TestCase;

public class PlayingCardTest extends TestCase {
	
	PlayingCardTest1 runTest = new PlayingCardTest1();
	
	public void testPlayingCard() {
		runTest.testPlayingCard();
	}
}
