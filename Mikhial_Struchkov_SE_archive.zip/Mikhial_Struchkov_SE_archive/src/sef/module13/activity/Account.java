package sef.module13.activity;

public interface Account {
	public int getID();
	public String getFirstName();
	public String getLastName();
	public String getEmail();
}
