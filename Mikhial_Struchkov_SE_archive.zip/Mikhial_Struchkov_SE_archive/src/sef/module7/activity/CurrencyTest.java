package sef.module7.activity;

import junit.framework.TestCase;

public class CurrencyTest extends TestCase {

	/**
	 *   
	 * 
	 * 
	 * 
	 * 
	 */
	
	
		CurrencyTest1 runTest = new CurrencyTest1();
		
	public void testCreateCurrency(){
		runTest.testCreateCurrency();
	}

	

}
