package sef.test.message;

public interface Message {
	
	String getText();

}
