package sef.module18.activity;

public interface Project {
	
	public void setProjectID(int id);
	public int getProjectID();
	
	public void setProjectName(String name);
	public String getProjectName();
	
	public void setProjectDescription(String description);
	public String getProjectDescription();
	
}
