package sef.module5.sample;

public interface Worker {

	public void doWork();
	
}
