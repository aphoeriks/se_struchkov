package sef.module5.sample;

public class WorkerImplB implements Worker{
	
	public void doWork(){
		System.out.println("Doing type-B work");
	}
}
