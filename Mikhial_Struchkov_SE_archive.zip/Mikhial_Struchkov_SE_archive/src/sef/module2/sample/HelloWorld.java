package sef.module2.sample;

public class HelloWorld {
	
	public static void main(String arg[]){
		System.out.println("Hello " + arg[0]);
	}
}
