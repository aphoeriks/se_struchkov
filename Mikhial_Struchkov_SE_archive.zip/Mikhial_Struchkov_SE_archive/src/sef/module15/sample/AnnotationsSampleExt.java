package sef.module15.sample;

public class AnnotationsSampleExt extends AnnotationsSample {

}
