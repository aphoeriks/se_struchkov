/*
 * Created on Jun 25, 2008
 *
 * Hello World Program
 */

package sef.module3.sample;

/**
* @author John Doe
*/
public class MainSample {

	public static void main(String[] args) {
		//	This line prints out the String 'Hello World!' in the console
		System.out.println( "Hello World!" );
		
		//	This line prints out the String parameter
		System.out.println(args[0]);
		
		//	This line is a sample statement that prints the sum of expression 1 + 2
		System.out.println(1 + 2);
		System.out.println("I'm expression1 " + "I'm expression2");
	}
}
